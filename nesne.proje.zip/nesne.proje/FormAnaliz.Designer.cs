﻿namespace nesne.proje
{
    partial class FormAnaliz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblToplam = new System.Windows.Forms.Label();
            this.lblEnHizli = new System.Windows.Forms.Label();
            this.lblEnTatli = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblToplam
            // 
            this.lblToplam.AutoSize = true;
            this.lblToplam.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblToplam.Location = new System.Drawing.Point(281, 66);
            this.lblToplam.Name = "lblToplam";
            this.lblToplam.Size = new System.Drawing.Size(76, 35);
            this.lblToplam.TabIndex = 0;
            this.lblToplam.Text = "label1";
            // 
            // lblEnHizli
            // 
            this.lblEnHizli.AutoSize = true;
            this.lblEnHizli.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblEnHizli.Location = new System.Drawing.Point(281, 174);
            this.lblEnHizli.Name = "lblEnHizli";
            this.lblEnHizli.Size = new System.Drawing.Size(76, 35);
            this.lblEnHizli.TabIndex = 1;
            this.lblEnHizli.Text = "label2";
            // 
            // lblEnTatli
            // 
            this.lblEnTatli.AutoSize = true;
            this.lblEnTatli.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.lblEnTatli.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblEnTatli.Location = new System.Drawing.Point(281, 272);
            this.lblEnTatli.Name = "lblEnTatli";
            this.lblEnTatli.Size = new System.Drawing.Size(76, 35);
            this.lblEnTatli.TabIndex = 2;
            this.lblEnTatli.Text = "label3";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.button1.Font = new System.Drawing.Font("Segoe Print", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(42, 405);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 35);
            this.button1.TabIndex = 3;
            this.button1.Text = "⬅GERİ";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormAnaliz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblEnTatli);
            this.Controls.Add(this.lblEnHizli);
            this.Controls.Add(this.lblToplam);
            this.Name = "FormAnaliz";
            this.Text = "FormAnaliz";
            this.Load += new System.EventHandler(this.FormAnaliz_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblToplam;
        private System.Windows.Forms.Label lblEnHizli;
        private System.Windows.Forms.Label lblEnTatli;
        private System.Windows.Forms.Button button1;
    }
}