﻿namespace nesne.proje
{
    partial class FormHesapla
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbTarifler = new System.Windows.Forms.ComboBox();
            this.numericUpDownPorsiyon = new System.Windows.Forms.NumericUpDown();
            this.listBoxTarifler = new System.Windows.Forms.ListBox();
            this.btnHesapla = new System.Windows.Forms.Button();
            this.lblSonuc = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPorsiyon)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbTarifler
            // 
            this.cmbTarifler.Font = new System.Drawing.Font("Segoe Print", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cmbTarifler.FormattingEnabled = true;
            this.cmbTarifler.Location = new System.Drawing.Point(322, 197);
            this.cmbTarifler.Name = "cmbTarifler";
            this.cmbTarifler.Size = new System.Drawing.Size(121, 31);
            this.cmbTarifler.TabIndex = 0;
            this.cmbTarifler.SelectedIndexChanged += new System.EventHandler(this.cmbTarifler_SelectedIndexChanged);
            // 
            // numericUpDownPorsiyon
            // 
            this.numericUpDownPorsiyon.Font = new System.Drawing.Font("Segoe Print", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.numericUpDownPorsiyon.Location = new System.Drawing.Point(322, 93);
            this.numericUpDownPorsiyon.Name = "numericUpDownPorsiyon";
            this.numericUpDownPorsiyon.Size = new System.Drawing.Size(120, 30);
            this.numericUpDownPorsiyon.TabIndex = 1;
            // 
            // listBoxTarifler
            // 
            this.listBoxTarifler.BackColor = System.Drawing.Color.LavenderBlush;
            this.listBoxTarifler.Font = new System.Drawing.Font("Segoe Print", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listBoxTarifler.FormattingEnabled = true;
            this.listBoxTarifler.ItemHeight = 23;
            this.listBoxTarifler.Location = new System.Drawing.Point(30, 49);
            this.listBoxTarifler.Name = "listBoxTarifler";
            this.listBoxTarifler.Size = new System.Drawing.Size(211, 211);
            this.listBoxTarifler.TabIndex = 2;
            this.listBoxTarifler.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // btnHesapla
            // 
            this.btnHesapla.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnHesapla.Font = new System.Drawing.Font("Segoe Print", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnHesapla.Location = new System.Drawing.Point(584, 303);
            this.btnHesapla.Name = "btnHesapla";
            this.btnHesapla.Size = new System.Drawing.Size(96, 47);
            this.btnHesapla.TabIndex = 3;
            this.btnHesapla.Text = "Hesapla";
            this.btnHesapla.UseVisualStyleBackColor = false;
            this.btnHesapla.Click += new System.EventHandler(this.btnHesapla_Click);
            // 
            // lblSonuc
            // 
            this.lblSonuc.AutoSize = true;
            this.lblSonuc.Location = new System.Drawing.Point(570, 137);
            this.lblSonuc.Name = "lblSonuc";
            this.lblSonuc.Size = new System.Drawing.Size(0, 16);
            this.lblSonuc.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Segoe Print", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(52, 392);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 38);
            this.button1.TabIndex = 5;
            this.button1.Text = "⬅GERİ DÖN";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormHesapla
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblSonuc);
            this.Controls.Add(this.btnHesapla);
            this.Controls.Add(this.listBoxTarifler);
            this.Controls.Add(this.numericUpDownPorsiyon);
            this.Controls.Add(this.cmbTarifler);
            this.Name = "FormHesapla";
            this.Text = "FormHesapla";
            this.Load += new System.EventHandler(this.FormHesapla_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPorsiyon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbTarifler;
        private System.Windows.Forms.NumericUpDown numericUpDownPorsiyon;
        private System.Windows.Forms.ListBox listBoxTarifler;
        private System.Windows.Forms.Button btnHesapla;
        private System.Windows.Forms.Label lblSonuc;
        private System.Windows.Forms.Button button1;
    }
}