﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TarifDefterim;

namespace nesne.proje
{
    public partial class FormHesapla : Form
    {
        public FormHesapla()
        {
            InitializeComponent();
        }

        private void cmbTarifler_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        private List<TatliTarifi> tumTarifler; 

        private async void FormHesapla_Load(object sender, EventArgs e)
        {
            try
            {
                FirebaseServisi servis = new FirebaseServisi();
                tumTarifler = await servis.TumTarifleriGetir();

                if (tumTarifler != null)
                {
                    listBoxTarifler.Items.Clear();
                    cmbTarifler.Items.Clear(); 

                    foreach (var tarif in tumTarifler)
                    {
                        listBoxTarifler.Items.Add(tarif.Ad);

                        
                        cmbTarifler.Items.Add(tarif.Ad);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Tarifler yüklenirken hata: " + ex.Message);
            }
        }

        private void btnHesapla_Click(object sender, EventArgs e)
        {
            
            string secilenIsim = "";

            if (cmbTarifler.SelectedItem != null)
            {
                secilenIsim = cmbTarifler.SelectedItem.ToString();
            }
            else if (listBoxTarifler.SelectedItem != null)
            {
                secilenIsim = listBoxTarifler.SelectedItem.ToString();
            }
            else
            {
                MessageBox.Show("Lütfen ListBox veya ComboBox üzerinden bir tarif seçin!");
                return;
            }

            
            var secilenTarif = tumTarifler.FirstOrDefault(t => t.Ad == secilenIsim);

            if (secilenTarif != null)
            {
               
                int porsiyon = (int)numericUpDownPorsiyon.Value;

                
                double toplamSeker = secilenTarif.SekerOraniGram * porsiyon;

               
                lblSonuc.Text = $"{secilenIsim} tarifi {porsiyon} porsiyon için \n" +
                                $"Toplam Şeker: {toplamSeker} gr.";
            }
            else
            {
                MessageBox.Show("Seçilen tarif detayları bulunamadı!");
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
