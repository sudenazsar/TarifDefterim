﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace nesne.proje
{
    public partial class FormDetay : Form
    {
        
        // Hatanın sebebi bu satırın eksik olmasıydı. Bunu ekleyince hata gidecek:
        public string GelenTarifAdi { get; set; }

        public FormDetay()
        {
            InitializeComponent();
        }

       





        private void FormDetay_Load_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(GelenTarifAdi))
            {
                lblBaslik.Text = "Seçilen Tarif: " + GelenTarifAdi;
            }
            else
            {
                lblBaslik.Text = "Tarif bilgisi yüklenemedi.";
            }
           
        }

        private async void btnSil_Click_2(object sender, EventArgs e)
        {
           
        {
                
                // Kullanıcıya onay soralım (Daha profesyonel görünür)
                DialogResult onay = MessageBox.Show($"{GelenTarifAdi} tarifini silmek istediğinize emin misiniz?",
                                              "Silme Onayı", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (onay == DialogResult.Yes)
            {
                try
                {
                    FirebaseServisi servis = new FirebaseServisi();
                    // Firebase üzerinden silme işlemini yapıyoruz
                    await servis.Sil(GelenTarifAdi);

                    MessageBox.Show("Tarif başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // İşlem bitince formu kapatıp listeye dönüyoruz
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Silme sırasında bir hata oluştu: " + ex.Message);
                }
            }
        }
    }

        private void button1_Click(object sender, EventArgs e)
        {
            // Form Detay ekranını kapatır ve bir önceki forma (Listeye) döner
            this.Close();
        }   
    }
}