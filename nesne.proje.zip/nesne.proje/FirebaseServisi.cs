﻿using Firebase.Database;
using Firebase.Database.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TarifDefterim;

public class FirebaseServisi
{
    
    private readonly string _firebaseUrl = "https://tarifdefterim-23cda-default-rtdb.europe-west1.firebasedatabase.app/";
    private readonly FirebaseClient _client;

    public FirebaseServisi()
    {
        
        _client = new FirebaseClient(_firebaseUrl);
    }

    
    public async Task TarifEkle(Tarif yeniTarif)
    {
        try
        {
            await _client
                .Child("Tarifler")
                .PostAsync(yeniTarif);
        }
        catch (Exception ex)
        {
            throw new Exception("Bağlantı Hatası: " + ex.Message);
        }
    }
    public async Task<List<TatliTarifi>> TumTarifleriGetir()
    {
        try
        {
            var tarifler = await _client
                .Child("Tarifler")
                .OnceAsync<TatliTarifi>();

            return tarifler.Select(item => new TatliTarifi
            {
                
                Ad = item.Object.Ad,
                HazirlamaSuresiDakika = item.Object.HazirlamaSuresiDakika,
                SekerOraniGram = item.Object.SekerOraniGram,
                SogutmaSuresiDakika = item.Object.SogutmaSuresiDakika,
                Aciklama = item.Object.Aciklama
            }).ToList();
        }
        catch (Exception)
        {
            
            return new List<TatliTarifi>();
        }
    }

        public async Task Sil(string tarifAdi)
    {
        
        var silinecek = (await _client
            .Child("Tarifler")
            .OnceAsync<TatliTarifi>())
            .FirstOrDefault(x => x.Object.Ad == tarifAdi);

        if (silinecek != null)
        {
            await _client.Child("Tarifler").Child(silinecek.Key).DeleteAsync();
        }
    }

}






