﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TarifDefterim

{
    public abstract class Tarif
    {
        public string TarifID { get; set; } 
        public string Ad { get; set; }
        public string Aciklama { get; set; }
        public List<string> Malzemeler { get; set; } 
        public int HazirlamaSuresiDakika { get; set; }


        public abstract string TurBilgisiniGoster();
        public string TumDetaylariGoster()
        {
           
            return $"Hazırlama Süresi: {HazirlamaSuresiDakika} dk\nGerekli Malzemeler: {string.Join(", ", Malzemeler)}";
        }

    }

    public class TatliTarifi : Tarif
    {
        public int SekerOraniGram { get; set; } 
        public int SogutmaSuresiDakika { get; set; }

        
        public override string TurBilgisiniGoster()
        {
            return $"[TATLI] - Şeker Oranı: {SekerOraniGram} gram. Dikkat: {SogutmaSuresiDakika} dk soğutma gerekir.";
        }

    }

    public class AnaYemekTarifi : Tarif
    {
        public int PorsiyonSayisi { get; set; }
        public string PisirmeTeknigi { get; set; } 

        
        public override string TurBilgisiniGoster()
        {
            return $"[ANA YEMEK] - {PorsiyonSayisi} Kişilik. Teknik: {PisirmeTeknigi}.";
        }
    }

}
