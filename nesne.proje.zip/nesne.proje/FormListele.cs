﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace nesne.proje
{
    public partial class FormListele : Form
    {
        public FormListele()
        {
            InitializeComponent();
        }

       
        
            private void btnGeriDon_Click(object sender, EventArgs e)
        {
            
            this.Close();
        }

        private async void FormListele_Load(object sender, EventArgs e)
        {
            {
                await VerileriListele(); 
            }
        }
        public async Task VerileriListele()
        {
            try
            {
                FirebaseServisi servis = new FirebaseServisi();
                var liste = await servis.TumTarifleriGetir();

                if (liste != null && liste.Count > 0)
                {
                    dgvTarifler.DataSource = null;
                    dgvTarifler.DataSource = liste;
                    dgvTarifler.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
                else
                {
                    MessageBox.Show("Henüz kayıtlı bir tarif bulunamadı.");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Veriler listelenirken teknik bir sorun oluştu.");
            }
        }

        private async void dgvTarifler_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) 
            {
                
                string secilenAd = dgvTarifler.Rows[e.RowIndex].Cells["Ad"].Value.ToString();

                
                FormDetay detay = new FormDetay();
                detay.GelenTarifAdi = secilenAd; 
                detay.ShowDialog();

                
               await VerileriListele();
            }
        }

       
    }
    }

