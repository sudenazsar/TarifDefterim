﻿namespace nesne.proje
{
    partial class FormListele
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvTarifler = new System.Windows.Forms.DataGridView();
            this.btnYenile = new System.Windows.Forms.Button();
            this.btnGeriDon = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTarifler)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvTarifler
            // 
            this.dgvTarifler.BackgroundColor = System.Drawing.Color.LavenderBlush;
            this.dgvTarifler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTarifler.Location = new System.Drawing.Point(22, 12);
            this.dgvTarifler.Name = "dgvTarifler";
            this.dgvTarifler.RowHeadersWidth = 51;
            this.dgvTarifler.RowTemplate.Height = 24;
            this.dgvTarifler.Size = new System.Drawing.Size(650, 354);
            this.dgvTarifler.TabIndex = 0;
            this.dgvTarifler.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTarifler_CellClick);
            // 
            // btnYenile
            // 
            this.btnYenile.Font = new System.Drawing.Font("Segoe Print", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnYenile.Location = new System.Drawing.Point(592, 401);
            this.btnYenile.Name = "btnYenile";
            this.btnYenile.Size = new System.Drawing.Size(196, 37);
            this.btnYenile.TabIndex = 1;
            this.btnYenile.Text = "Listeyi Yenile";
            this.btnYenile.UseVisualStyleBackColor = true;
            // 
            // btnGeriDon
            // 
            this.btnGeriDon.Font = new System.Drawing.Font("Segoe Print", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGeriDon.Location = new System.Drawing.Point(12, 401);
            this.btnGeriDon.Name = "btnGeriDon";
            this.btnGeriDon.Size = new System.Drawing.Size(199, 37);
            this.btnGeriDon.TabIndex = 2;
            this.btnGeriDon.Text = "⬅ Ana Menüye Dön";
            this.btnGeriDon.UseVisualStyleBackColor = true;
            this.btnGeriDon.Click += new System.EventHandler(this.btnGeriDon_Click);
            // 
            // FormListele
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LemonChiffon;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnGeriDon);
            this.Controls.Add(this.btnYenile);
            this.Controls.Add(this.dgvTarifler);
            this.Name = "FormListele";
            this.Text = "FormListele";
            this.Load += new System.EventHandler(this.FormListele_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTarifler)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvTarifler;
        private System.Windows.Forms.Button btnYenile;
        private System.Windows.Forms.Button btnGeriDon;
    }
}