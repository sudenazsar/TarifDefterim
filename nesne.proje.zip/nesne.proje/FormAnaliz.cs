﻿using System;
using System.Collections.Generic;
using System.Linq; 
using System.Windows.Forms;
using TarifDefterim;

namespace nesne.proje 
{
    public partial class FormAnaliz : Form
    {
        public FormAnaliz()
        {
            InitializeComponent();
        }

        
        

        private async void FormAnaliz_Load(object sender, EventArgs e)
        {
            try
            {
                FirebaseServisi servis = new FirebaseServisi();
                List<TatliTarifi> liste = await servis.TumTarifleriGetir();

                if (liste != null && liste.Count > 0)
                {
                    
                    lblToplam.Text = "Sistemdeki Toplam Tarif Sayısı: " + liste.Count;


                    var enPratik = liste.OrderBy(x => x.HazirlamaSuresiDakika).First();
                    lblEnHizli.Text = $"En Pratik Tarif: {enPratik.Ad} ({enPratik.HazirlamaSuresiDakika} dk)";

                    
                    var enTatli = liste.OrderByDescending(x => x.SekerOraniGram).First();
                    lblEnTatli.Text = $"En Tatlı Tarif: {enTatli.Ad} ({enTatli.SekerOraniGram} gr şeker)";
                }
                else
                {
                    lblToplam.Text = "Henüz kayıtlı tarif yok.";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veriler analiz edilirken hata oluştu: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
               
                this.Close();
            
        }
    }
}