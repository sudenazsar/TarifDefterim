﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TarifDefterim;

namespace nesne.proje
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void btnKaydet_Click(object sender, EventArgs e)
        {
                try
            {
                //  Boş Alan Kontrolü 
                if (string.IsNullOrWhiteSpace(txtAd.Text) || string.IsNullOrWhiteSpace(txtSure.Text))
                {
                    MessageBox.Show("Lütfen Yemek Adı ve Süre alanlarını boş bırakmayın!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                
                FirebaseServisi servis = new FirebaseServisi();

                
                TatliTarifi yeniTatli = new TatliTarifi
                {
                    Ad = txtAd.Text,
                    
                    HazirlamaSuresiDakika = int.Parse(txtSure.Text),
                    SekerOraniGram = int.Parse(txtSeker.Text),
                    Aciklama = txtAciklama.Text
                };

               
                await servis.TarifEkle(yeniTatli);

                
                MessageBox.Show($"{yeniTatli.Ad} başarıyla deftere kaydedildi!", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);

                FormuTemizle();
            }
            catch (FormatException)
            {
                MessageBox.Show("Süre ve Şeker alanlarına sadece sayı girmelisiniz!", "Giriş Hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bir hata oluştu: " + ex.Message);
            }
        }

        
        private void FormuTemizle()
        {
            txtAd.Clear();
            txtSure.Clear();
            txtSeker.Clear();
            txtAciklama.Clear();
            txtAd.Focus();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

         
            private void btnListeyeGit_Click(object sender, EventArgs e)
        {
            
            FormListele listeFormu = new FormListele();

            
            listeFormu.Show();
        }

        private void btnHesapla_Click(object sender, EventArgs e)
        {
            FormHesapla frm = new FormHesapla();
            frm.Show();
        }

        private void btnAnaliz_Click(object sender, EventArgs e)
        {
            FormAnaliz frm = new FormAnaliz();
            frm.Show(); 
        }
    }
}

