﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TarifDefterim

{
    public class Kullanici
    {
        public string UyeID { get; set; } // Firebase User ID
        public string AdSoyad { get; set; }
        public string Email { get; set; } // Giriş için kullanılacak
        public string Rol { get; set; }
    }

}
