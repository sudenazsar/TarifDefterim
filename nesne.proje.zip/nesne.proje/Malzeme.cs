﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TarifDefterim

{
    public class Malzeme
    {
        public string MalzemeID { get; set; } 
        public string Ad { get; set; } 
    }
}
